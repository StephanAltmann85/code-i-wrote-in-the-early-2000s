<?php
include "lib/global.php";

$code = $_GET["code"];
$error = $_GET["error"];
$action = $_GET["action"];
$email = $_GET["email"];

$date = time();
$time = date("H:m");

eval("\$head = \"".$template->tpl("head.htm")."\";");
eval("\$footer = \"".$template->tpl("footer.htm")."\";");

if(!$code)
{
  $action = "error";
  $error = "no_code";
}

switch($action)
{
  case "error": switch($error)
                {
                  case "no_code": eval("\$message = \"".$template->tpl("save_error_no_code.htm")."\";");
                  break;

                  case "incorrect_code": eval("\$message = \"".$template->tpl("save_error_incorrect_code.htm")."\";");
                  break;
                }
  break;

  default: $query = $database->db_query("SELECT email FROM fn" . $sql_prefix . "_entries WHERE activation_code = '$code' AND activated = '0'");
           $entries = mysql_num_rows($query);
           $entry = mysql_fetch_array($query);

           if($entries)
           {
             $query = $database->db_query("UPDATE fn" . $sql_prefix . "_entries SET activated = '1' WHERE activation_code = '$code'");

             $query = $database->db_query("INSERT INTO fn" . $sql_prefix . "_log (`date` ,`email` ,`ip` , `action`) VALUES ('$date', '$entry[email]', '$_SERVER[REMOTE_ADDR]', 'Speichern der Mailadresse in der Datenbank (save.php)')");

             if($options["notify"])
             {
               eval("\$notify = \"".$template->tpl("notify.htm")."\";");
               $header = $mail->simple_textmail();
               mail($options[email], "Neue Registrierung", $notify, $header);
             }

             eval("\$message = \"".$template->tpl("save_done.htm")."\";");
           } else header("Location: save.php?action=error&error=incorrect_code&code=$code");
  break;
}

eval("\$template->tpl_output(\"".$template->tpl("save.htm")."\");");

?>