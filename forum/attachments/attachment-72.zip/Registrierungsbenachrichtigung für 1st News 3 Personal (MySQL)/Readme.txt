Registrierungsbenachrichtigung f�r 1st News 3 Personal (MySQL)


#Installation
1.)F�hren Sie z.B. mit PHPMyAdmin folgende Datenbankabfrage aus:
ALTER TABLE `fn1_options` ADD `notify` INT( 1 ) DEFAULT '0' NOT NULL ;

Alternativ k�nnen Sie auch die Datei DB.sql aufrufen.

2.) 
Ersetzten sie folgende Dateien:
-save.php
-acp/index.php
-acp/templates/options_general.htm

3.)
Laden Sie die Datei templates/notify.htm auf den Server