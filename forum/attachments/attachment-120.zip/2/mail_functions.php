<?php
class mail_class
{
  function header($mail_modus, $attachments)
  {
    global $options;

    $header = "From: $options[name_mail] <$options[email]>\n";
    $header .= "Return-Path: <$options[email]>\n";
    
    if($attachments)
    {
      $header .= "MIME-version: 1.0\n";
      $header .= "Content-type: multipart/mixed; boundary=\"Message-Boundary\"\n\n";
    }
    else
    {
      if($mail_modus == "html")
      {
        $header .= "Content-Type: text/html\n";
        $header .= "Content-Transfer-Encoding: 8Bit\n";
      }
      else
      {
        $header .= "Content-Type: text/plain\n";
        $header .= "Content-Transfer-Encoding: 8Bit\n";
      }
    }
    return $header;
  }

  function body_begin($mail_modus, $attachments)
  {
    if($attachments)
    {
      $body = "--Message-Boundary\n";

      if($mail_modus == "html") $body.= "Content-type: text/html; charset=iso-8859-1\n";
      else $body.= "Content-type: text/plain; charset=iso-8859-1\n";

      $body.= "Content-transfer-encoding: 8Bit\n\n";

      return $body;
    } else return "";
  }

  function body_end($attachments)
  {
    if($attachments)
    {
      $attachment = split(";", $attachments);
      $count = count($attachment) - 1;
      $i = 0;
      
      while($i < $count)
      {
        $file_name = $attachment[$i];
        $file_size = filesize("attachments/temp/" . $file_name);
        $file_type = filetype("attachments/temp/" . $file_name);

        $fp = fopen("attachments/temp/" . $file_name, "r");
        $contents = fread($fp, $file_size);
        $encoded_file = chunk_split(base64_encode($contents));
        fclose($fp);

        $body .= "\n\n--Message-Boundary\n";
        $body .= "Content-type: $file_type; name=\"$file_name\"\n";
        $body .= "Content-Transfer-Encoding: BASE64\n";
        $body .= "Content-Disposition: attachment; filename=\"$file_name\"\n";
        $body .= "Content-ID: $file_name\n\n";
        $body .= "$encoded_file\n";

        @unlink("attachments/temp/" . $file_name);
        $i++;
      }
      $body .= "--Message-Boundary--\n";

      return $body;
    } else return "";
  }

  function message($mail_modus, $attachments, $textarea)
  {
    //$textarea = stripslashes($textarea);
    return $this->body_begin($mail_modus, $attachments) . str_replace("[attachment]/", "cid:", $textarea) . $this->removal_direction($mail_modus) . $this->body_end($attachments);
  }

  function removal_direction($mail_modus)
  {
    global $options;

    if($mail_modus == "html") $direction = "<br>\n<br>\n-----------<br>\n" . str_replace("{firstnews}", "<a href=\"". $options["url"] . "\" target=\"_blank\">" . $options["url"] . "</a>", nl2br($options["remove_notice"]));
    else $direction = "\n\n-----------\n" . str_replace("{firstnews}", $options["url"], $options["remove_notice"]);

    return $direction;
  }

  function simple_textmail()
  {
    global $options;

    $header = "From: $options[name_mail] <$options[email]>\n";
    $header .= "Return-Path: <$options[email]>\n";
    $header .= "MIME-Version: 1.0\n";
    $header .= "Content-Type: text/plain; charset=\"iso-8859-1\"\n";
    $header .= "Content-Transfer-Encoding: 7bit";

    return $header;
  }
}

?>
