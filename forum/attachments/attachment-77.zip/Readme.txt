Autor: Stephan Altmann
Homepage: http://www.programmers-club.de
Projektseite: http://www.programmers-club.de/firstnews

Vorgehensweise:
1.) Outlook-Kontakte laden
2.) 1st News - Kontakte laden
3.) Kontakte zusammenf�hren
4.) Datei erstellen