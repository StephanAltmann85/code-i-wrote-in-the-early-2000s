<?php
setcookie("ACPpassword", "", 0);
header("Location: index.php");
?>
