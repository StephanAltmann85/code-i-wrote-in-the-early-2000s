<?
function replace($tmp)
{
  global $conn;
  global $design_table;

  $result = mysql_query("SELECT name, content FROM $design_table", $conn);

  while($row=mysql_fetch_row($result))
  {
    $code = $row[0];
    $replace = $row[1];
    $tmp = str_replace("$code", "$replace", $tmp);
  }

  return $tmp;
}

function tpl($template)
{
  global $conn;
  global $templates_table;
  $result = mysql_query("SELECT code FROM $templates_table WHERE name = '$template'", $conn);
  return replace(implode(mysql_fetch_row($result), ""), $conn);
}

function tpl_insert($code, $template_insert)
{
  global $tpl;
  return str_replace($code, $template_insert, $tpl);
}

function tpl_output($template)
{
  print $template;
}
?>