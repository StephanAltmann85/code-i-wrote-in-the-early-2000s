<?

$location = "board";

include("global.php");

$tpl = tpl("board");
$tpl = tpl_insert("#header", tpl("header"));
$tpl = tpl_insert("#head", tpl("head"));
$tpl = str_replace("\$boardid", $boardid, $tpl);

$r = mysql_query("SELECT id, author, title, time FROM $threads_table WHERE boardid = '$boardid'", $conn);

unset($i);

while ($row = mysql_fetch_row($r))
{
  $threadid = $row[0];
  $author = $row[1];
  $title = $row[2];
  $time = $row[3];

  $result = mysql_query("SELECT * FROM $messages_table Where threadid = '$threadid'");
  $replys_count = mysql_num_rows($result) -1;

  unset($tmp);

  $tmp = str_replace("\$threadid", $threadid, tpl("board_list_threads"));
  $tmp = str_replace("\$title", $title, $tmp);
  $tmp = str_replace("\$author", $author, $tmp);
  $tmp = str_replace("\$replys_count", $replys_count, $tmp);

  $Template[$i] = $tmp;
  $i++;
}

if($title) $tpl = tpl_insert("#board_list_threads", implode($Template, "")); else $tpl = tpl_insert("#board_list_threads", "");

$tpl = tpl_insert("#footer", tpl("footer"));
tpl_output($tpl);

?>