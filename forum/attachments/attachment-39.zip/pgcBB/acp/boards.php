<?
include("../global.php");

switch($adbo)
{
default:
  if($sent == '1')
  {
    mysql_select_db ($maindb, $conn);
    if(empty($boardname) || empty($description))
      { die('Sie haben nicht die n�tigen Felder ausgef�llt. <a href="javascript:history.back()">Zur�ck</a>'); }
    $r = mysql_query("INSERT INTO $boards_table (name, description) VALUES ('$boardname', '$description')");
    if(!$r)
      { die('Sorry, konnte Forum nicht anlegen. <a href="javascript:history.back()">Zur�ck</a>'); }
    echo 'Forum Angelegt. <a href="../">Zur�ck zur Startseite</a>';
  }
  else
  {
?>

<h3>Forum Hinzuf�gen</h3>
<form action="boards.php" method="post">
<table border="0" width="500" cellpadding="4" cellspacing="0">
  <tr>
    <td width="200"><b>Name:</b></td>
    <td width="300"><input type="text" name="boardname" size="30"></td>
  </tr>
  <tr>
    <td><b>Beschreibung:</b></td>
    <td><input type="text" name="description" size="30"></td>
  </tr>
  <tr>
    <td></td>
    <td><input type="submit"></td>
  </tr>
</table>
<input type="hidden" name="sent" value="1">
</form>

<a href="boards.php?adbo=show">Alle Foren zeigen</a>

<?
  }
break;

case "show":
  mysql_select_db ($maindb, $conn);
  $r = mysql_query("SELECT name, description, id FROM $boards_table");

  if(mysql_num_rows($r) == '0')
    { die('Keine Foren vorhanden. <a href="javascript:history.back()">Zur�ck</a>'); }

  while($row = mysql_fetch_array($r))
  {
    echo '<a href="boards.php?adbo=edit&id='.$row[id].'">'.$row[name].'<br>';
  }
break;

case "edit":
  if($sent == '2')
  {
    if($del == '1')
    {
      mysql_select_db ($maindb, $conn);
      $d = mysql_query("DELETE FROM $boards_table WHERE id = '$id'");

      if(!$d)
        { die('Daten konnte nicht gel�scht werden. <a href="javascript:history.back()">Zur�ck</a>'); }
      echo 'Daten gel�scht. <a href="../">Zur�ck zur �bersicht</a>';
    }
    else
    {
      mysql_select_db ($maindb, $conn);

      if(empty($boardname) || empty($description))
        { die('Sie haben nicht die n�tigen Felder ausgef�llt. <a href="javascript:history.back()">Zur�ck</a>'); }

      $i = mysql_query("UPDATE $boards_table SET name='$boardname', description='$desctiption' WHERE id = '$id'");

      if(!$i)
        { die('Sorry, konnte Daten nicht editieren. <a href="javascript:history.back()">Zur�ck</a>'); }
      echo 'Daten editiert. <a href="../">Zur�ck zur Startseite</a>';
    }
  }
  else
  {
    mysql_select_db ($maindb, $conn);
    $r = mysql_query("SELECT name, description FROM $boards_table WHERE id = '$id'");

    while($row = mysql_fetch_array($r))
    {
?>

<h3>Forum editieren</h3>
<form action="boards.php?adbo=edit&id=<?= $id ?>" method="post">
<table border="0" width="500" cellpadding="4" cellspacing="0">
  <tr>
    <td width="200"><b>Name:</b></td>
    <td width="300"><input type="text" name="boardname" size="30" value="<?= $row[name] ?>"></td>
  </tr>
  <tr>
    <td><b>Beschreibung:</b></td>
    <td><input type="text" name="description" size="30" value="<?= $row[description] ?>"></td>
  </tr>
  <tr>
    <td><input type="checkbox" name="del" value="1"> L�schen?</td>
    <td><input type="submit"></td>
  </tr>
</table>
<input type="hidden" name="sent" value="2">
</form>

<?
    }
  }
break;

}

?>