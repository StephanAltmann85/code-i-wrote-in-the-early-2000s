<?php

$location = "newthread";

include("global.php");

$tpl = tpl("newthread");

$tpl = tpl_insert("#header", tpl("header"));
$tpl = tpl_insert("#head", tpl("head"));

if ($action == "create_newthread")
{
  if($title && $message)
  {
    $r = mysql_query("SELECT MAX(id) FROM $messages_table", $conn);
    $messages_count = mysql_fetch_row($r);

    $r2 = mysql_query("SELECT MAX(id) FROM $threads_table", $conn);
    $max_threadid = mysql_fetch_row($r2);
    $threadid = $max_threadid[0]+1;

    $sql  = "INSERT INTO $messages_table (boardid, threadid, title, message, author, time) VALUES ('$boardid', '$threadid', '$title', '$message', '$author', '$time')";
    $r = mysql_query ($sql, $conn);

    $sql  = "INSERT INTO $threads_table (boardid, title, author, time) VALUES ('$boardid', '$title', '$author', '$time')";
    $r = mysql_query ($sql, $conn);

    if ($r) header("Location: thread.php?threadid=$threadid");
  }
  else
  {
    $tpl = tpl_insert("#newthread", tpl("newthread_missing_infos"));
  }
}
else
{
  $tpl = tpl_insert("#newthread", tpl("newthread_create_new"));
  $tpl = str_replace("\$boardid", $boardid, $tpl);
}

$tpl = tpl_insert("#footer", tpl("footer"));
tpl_output($tpl);

?>