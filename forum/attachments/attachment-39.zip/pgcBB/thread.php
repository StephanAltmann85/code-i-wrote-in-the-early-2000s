<?php

$location = "thread";

include("global.php");

$tpl = tpl("thread");
$tpl = tpl_insert("#header", tpl("header"));
$tpl = tpl_insert("#head", tpl("head"));

$r = mysql_query("SELECT boardid, threadid, title, message, author, time  FROM $messages_table WHERE threadid = '$threadid' ORDER BY time ASC", $conn);

unset($i);

while ($row = mysql_fetch_row ($r))
{
  $boardid = $row[0];
  $threadid = $row[1];
  $title = $row[2];
  $message = str_replace("\n", "<br>", $row[3]);
  $author = $row[4];
  $time = $row[5];

  $message = str_replace("\n", "<br>", $message);

  unset($tmp);

  $tmp = str_replace("\$boardid", $boardid, tpl("thread_table_threads"));
  $tmp = str_replace("\$threadid", $threadid, $tmp);
  $tmp = str_replace("\$message", $message, $tmp);
  $tmp = str_replace("\$author", $author, $tmp);
  $tmp = str_replace("\$title", $title, $tmp);

  $Template[$i] = $tmp;
  $i++;
}

if($title) $tpl = tpl_insert("#thread_table_threads", implode($Template, "")); else $tpl = tpl_insert("#thread_table_threads", "");

$tpl = tpl_insert("#footer", tpl("footer"));
tpl_output($tpl);
?>