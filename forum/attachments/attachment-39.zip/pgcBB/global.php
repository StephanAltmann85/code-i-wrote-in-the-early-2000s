<?php

require("config_inc.php");
require("template.php");

$messages_table = 'pgcbb'.$db_praefix.'_messages';
$boards_table = 'pgcbb'.$db_praefix.'_boards';
$templates_table = 'pgcbb'.$db_praefix.'_templates';
$bbcode_table = 'pgcbb'.$db_praefix.'_bbcode';
$cats_table = 'pgcbb'.$db_praefix.'_categ';
$threads_table = 'pgcbb'.$db_praefix.'_threads';
$design_table = 'pgcbb'.$db_praefix.'_design';  //Ortsangabe der einzelnen Spalten

$conn = mysql_connect($sqlserver, $sqluser, $sqlpwd);
$select = mysql_select_db($maindb, $conn);  //Verbindung zur Datenbank erstellen

$timestamp = mktime();

?>