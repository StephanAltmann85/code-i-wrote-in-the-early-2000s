<?php

$location = "index";

include("global.php");

$tpl = tpl("index");
$tpl = tpl_insert("#header", tpl("header"));
$tpl = tpl_insert("#head", tpl("head"));

unset($i);
$cats = mysql_query("SELECT * FROM $cats_table ORDER BY sort ASC", $conn);

while ($row = mysql_fetch_row($cats))
{
  $catid = $row[0];
  $catname = $row[1];
  $catdescription = $row[2];

  unset($tmp);

  $tmp = str_replace("\$catname", $catname, tpl("index_cat"));
  $tmp = str_replace("\$catid", $catid, $tmp);
  $tmp = str_replace("\$catdescription", $catdescription, $tmp);

  $boards = mysql_query("SELECT * FROM $boards_table where categ = '$catid' ORDER BY sort ASC", $conn);

  while ($row = mysql_fetch_row($boards))
  {
    $boardid = $row[0];
    $boardname = $row[1];
    $boarddescription = $row[2];

    $threads_count = mysql_query("SELECT id FROM $threads_table where boardid = '$boardid'");
    $threads_count = mysql_num_rows($threads_count);

    $messages_count = mysql_query("SELECT id FROM $messages_table where boardid = '$boardid'");
    $messages_count = mysql_num_rows($messages_count);

    $tmp .= str_replace("\$boardname", $boardname, tpl("index_list_forums"));
    $tmp = str_replace("\$boardid", $boardid, $tmp);
    $tmp = str_replace("\$threads_count", $threads_count, $tmp);
    $tmp = str_replace("\$messages_count", $messages_count, $tmp);
    $tmp = str_replace("\$boarddescription", $boarddescription, $tmp);
  }

  $Template[$i] = $tmp;
  $i++;
}

if($catname) $tpl = tpl_insert("#index_list_forums", implode($Template, "")); else $tpl = tpl_insert("#index_list_forums", "");

$tpl = tpl_insert("#footer", tpl("footer"));

tpl_output($tpl);

?>