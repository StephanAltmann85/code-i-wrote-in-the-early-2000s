<? 
$sqlserver = "localhost"; 
$maindb = "pgcbb"; 
$sqluser = "root1"; 
$sqlpwd = ""; 
$db_praefix = "1"; 
?>