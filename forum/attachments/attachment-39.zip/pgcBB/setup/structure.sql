CREATE TABLE `pgcbb1_bbcode` (
  `id` int(14) NOT NULL auto_increment,
  `code` text,
  `replace` text,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

CREATE TABLE `pgcbb1_boards` (
  `id` int(14) NOT NULL auto_increment,
  `name` text,
  `description` text,
  `sort` int(14) default '0',
  `categ` int(14) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

CREATE TABLE `pgcbb1_categ` (
  `id` int(14) NOT NULL auto_increment,
  `name` text,
  `description` text,
  `sort` int(14) default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

CREATE TABLE `pgcbb1_design` (
  `id` int(14) NOT NULL auto_increment,
  `designpackid` int(14) NOT NULL default '0',
  `name` text,
  `content` text,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

CREATE TABLE `pgcbb1_messages` (
  `id` int(14) NOT NULL auto_increment,
  `boardid` int(14) NOT NULL default '0',
  `threadid` int(14) NOT NULL default '0',
  `title` text,
  `message` text,
  `author` varchar(255) default NULL,
  `time` int(14) default NULL,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

CREATE TABLE `pgcbb1_templates` (
  `id` int(14) NOT NULL auto_increment,
  `name` text,
  `code` text,
  `templatepack` int(14) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;

CREATE TABLE `pgcbb1_threads` (
  `id` int(14) NOT NULL auto_increment,
  `boardid` int(14) NOT NULL default '0',
  `author` text,
  `title` text,
  `time` text,
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;