DROP TABLE IF EXISTS `pgcbb1_bbcode`;
DROP TABLE IF EXISTS `pgcbb1_boards`;
DROP TABLE IF EXISTS `pgcbb1_categ`;
DROP TABLE IF EXISTS `pgcbb1_design`;
DROP TABLE IF EXISTS `pgcbb1_messages`;
DROP TABLE IF EXISTS `pgcbb1_templates`;
DROP TABLE IF EXISTS `pgcbb1_threads`;