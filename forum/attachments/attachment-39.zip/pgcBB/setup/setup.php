<html>
<head>
<style type="text/css">
<!--
body {
 font-family: Verdana;
 font-size: 8pt;
 text-align: left;
 color: #0E3989;
 background: #FFFFFF;
 margin-left: 20;
 margin-top: 20;
 margin-bottom: 0;
 margin-right: 0;

 scrollbar-base-color: #FFFFFF;
 scrollbar-3dlight-color: #DFDFDF;
 scrollbar-arrow-color: #FFFFFF;
 scrollbar-darkshadow-color: #0E3989;
 scrollbar-face-color: #7F99B2;
 scrollbar-highlight-color: #B3C2D2;
 scrollbar-shadow-color: #000000;
 scrollbar-track-color: #7F99B2;
}
table {
 font-family: Verdana;
 font-size: 8pt;
 text-align: left;
 color: #0E3989;
}
.info {
 font-family: Verdana;
 font-size: 14pt;
 text-align: left;
 color: #0E3989;
 font-weight: bold;
}
textarea, input {
 font-family: Verdana;
 font-size: 8pt;
 font-weight: bold;
 color: #0E3989;
 BACKGROUND-COLOR: #FFFFFF;

 border-top-width : 1px;
 border-right-width : 1px;
 border-bottom-width : 1px;
 border-left-width : 1px;

 border-top-color : #000000;
 border-right-color : #000000;
 border-bottom-color : #000000;
 border-left-color : #000000;
}
a {
 font-family: Verdana;
 color: #0E3989;
}
a:hover {
 color: #800000;
 text-decoration: none;
}
-->
</style>
</head>

</body>
<?


switch($action)
{
  default: echo("<div class=\"info\">Installation des pgcBB</div>
<table height=\"80%\" width=\"100%\">
<tr valign=\"center\">
 <td align=\"center\">
  <form action=\"setup.php\" method=\"post\">
  <table style=\"background-color: #000000\" cellpadding=\"2\" cellspacing=\"1\">
  <input type=\"hidden\" name=\"action\" value=\"create\">
  <tr style=\"background-image:url(../images/bigback.gif)\">
   <td width=\"100\"><b>Willkommen</b></td>
   <td> </td>
  </tr>
  <tr style=\"background-color: #FFFFFF\">
   <td>SQL-Server:</td>
   <td>&nbsp;<input type=\"Text\" name=\"sqlserver\" value=\"localhost\" size=\"30\">&nbsp;</td>
  </tr>
  <tr style=\"background-color: #FFFFFF\">
   <td>Datenbank:</td>
   <td>&nbsp;<input type=\"Text\" name=\"maindb\" value=\"pgcbb\" size=\"30\">&nbsp;</td>
  </tr>
  <tr style=\"background-color: #FFFFFF\">
   <td>SQL-Login:</td>
   <td>&nbsp;<input type=\"Text\" name=\"sqluser\" value=\"root\" size=\"30\">&nbsp;</td>
  </tr>
  <tr style=\"background-color: #FFFFFF\">
   <td>SQL-Passwort:</td>
   <td>&nbsp;<input type=\"Text\" name=\"sqlpwd\" value=\"\" size=\"30\">&nbsp;</td>
  </tr>
  <tr style=\"background-color: #FFFFFF\">
   <td>Pr&auml;fix:</td>
   <td>&nbsp;<input type=\"Text\" name=\"db_praefix\" value=\"1\" size=\"30\">&nbsp;</td>
  </tr>
  <tr style=\"background-color: #FFFFFF\" height=\"30\">
   <td colspan=\"2\" align=\"center\"><input type=\"Submit\" name=\"send\" value=\"Weiter\">&nbsp;&nbsp;<input type=\"reset\"></th>
  </tr>
  </table><br><br><br>

  <table style=\"background-color: #000000\" cellpadding=\"2\" cellspacing=\"1\" width=\"320\">
  <tr style=\"background-image:url(../images/bigback.gif)\">
   <td ><b>Hinweise zur Einstellung - Pr&auml;fix</b></td>
  </tr>
  <tr style=\"background-color: #FFFFFF\">
   <td>Sollte Ihnen aus irgendeinen Grund nur eine Tabelle zur Verf&uuml;gung stehen, dann k&ouml;nnen Sie auch mehrere pgcBBs in eine Tabelle installieren. Es wird in einem solchem Fall empfohlen die Pr&auml;fixe fortlaufend zu vergeben.<br><br><b>Bsp.:</b><br>Board 1 - Pr&auml;fix 1<br>Board 2 - Pr&auml;fix 2<br>...</td>
  </tr>
  </table><br><br><br>

  <div align=\"center\"><hr noshade size=\"1\" width=\"60%\"><i>pgcBB by <a href=\"http://www.programmers-club.de\" target=\"_blank\">Programmers Club</a></i></div>
 </td>
</tr>
</table></form><br><br>");
  break;

  case "create":
    if(!$conn = mysql_connect($sqlserver, $sqluser, $sqlpwd)) echo "<font color=\"#880000\"><b>Es konnte keine Verbindung zur Datenbank hergestellt werden!</b></font><br>"; else echo "<b>Verbindung zur Datenbank erfolgreich hergestellt...</b><br>";
    if(!mysql_select_db($maindb, $conn)) echo "<font color=\"#880000\"><b>Die gew&auml;hlte Tabelle ($maindb) existiert nicht!</b></font>"; else echo "<b>Die Tabelle $maindb wurde gefunden...</b><br>";

    $sql_file = implode(file("drops.sql"), "");
    $sql_array = split("(;)",$sql_file);

    for ($i=0;$i!=count($sql_array) -1;$i++)
    {
      $sql = $sql_array[$i];
      $sql = str_replace("pgcbb1_", "pgcbb" . $db_praefix . "_", $sql);
      $r = mysql_query("$sql");
    }

    $sql_file = implode(file("structure.sql"), "");
    $sql_array = split("(;)",$sql_file);

    for ($i=0;$i!=count($sql_array) -1;$i++)
    {
      $sql = $sql_array[$i];
      $sql = str_replace("pgcbb1_", "pgcbb" . $db_praefix . "_", $sql);
      $table_name = split("`",$sql);
      if($r = mysql_query("$sql")) echo "<b>Tabelle $table_name[1] konnte erfolgreich erstellt werden...</b><br>"; else echo "<font color=\"#880000\"><b>Tabelle $table_name[1] konnte nicht erstellt werden!...</b></font><br>";
    }

    $sql_file = implode(file("inserts.sql"), "");
    $sql_array = split(");#",$sql_file);

    for ($i=0;$i!=count($sql_array) -1;$i++)
    {
      $sql = $sql_array[$i];
      $sql = $sql . ")";

      $sql = str_replace("pgcbb1_", "pgcbb" . $db_praefix . "_", $sql);
      $table_name = split("`",$sql);
      if($r = mysql_query("$sql")) echo "<b>Daten f&uuml;r Tabelle $table_name[1] erfolgreich geladen...</b><br>"; else echo "<font color=\"#880000\"><b>Daten f&uuml;r Tabelle $table_name[1] konnten nicht geladen werden!...</b></font><br>";
    }

    $write_config = "<"."? \n\$sqlserver = \"$sqlserver\"; \n\$maindb = \"$maindb\"; \n\$sqluser = \"$sqluser\"; \n\$sqlpwd = \"$sqlpwd\"; \n\$db_praefix = \"$db_praefix\"; \n?".">";

    $fp = fopen("../config_inc.php","w");
    fputs($fp, $write_config);
    fclose($fp);

  break;
}
?>
</body>
</html>