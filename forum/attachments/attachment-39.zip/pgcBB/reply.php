<?php

$location = "reply";

include("global.php");

$tpl = tpl("reply");

$tpl = tpl_insert("#header", tpl("header"));
$tpl = tpl_insert("#head", tpl("head"));

if ($action == "save_reply")
{
  if($author && $title && $message)
  {
    $boardid = mysql_query("SELECT boardid FROM $threads_table where id = '$threadid'");
    $boardid = mysql_result($boardid, 0, "boardid");

    $sql  = "INSERT INTO $messages_table (boardid, threadid, title, message, author, time) VALUES ('$boardid', '$threadid', '$title', '$message', '$author', '$time')";
    $r = mysql_query ($sql, $conn);

    if ($r) header("Location: thread.php?threadid=$threadid");
  }
  else
  {
    $tpl = tpl_insert("#reply", tpl("reply_missing_infos"));
  }
}
else
{
  $tpl = tpl_insert("#reply", tpl("reply_create_new"));
  $tpl = str_replace("\$threadid", $threadid, $tpl);
}

$tpl = tpl_insert("#footer", tpl("footer"));
tpl_output($tpl);

?>