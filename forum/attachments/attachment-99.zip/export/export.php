<?php
include("../lib/config_data.php");
include("../lib/database_class.php");

$database = new database_class;
$database->db_connect();

if($_REQUEST["action"] =="save")
{
  if($_REQUEST["split"] == "break") $split_string = "\n";
  if($_REQUEST["split"] == "breakr") $split_string = "\r\n";
  if($_REQUEST["split"] == "other") $split_string = $_REQUEST["split_string"];

  $i = 0;

  $query = $database->db_query("SELECT `email` FROM `fn" . $sql_prefix . "_entries` WHERE `group` = '$_REQUEST[group]' ORDER BY `email` ASC");
  while($emails = @mysql_fetch_row($query))
  {
    $array_of_entries[$i] = $emails[0];
    $i++;
  }

  header("Content-type: application/octet-stream");
  header("Content-disposition: attachment; filename=group_$_REQUEST[group].txt");
  echo implode($split_string, $array_of_entries);
} else
{
  echo "

<html>
<head>
<title>1st News [Export]</title>
<meta name=\"author\" content=\"Stephan Altmann\">

<style type=\"text/css\">
<!--
body {
 font-family: Verdana;
 font-size: 10px;
 text-align: left;
 color: #0E3989;
 background: #FFFFFF;

 margin-top: 10px;
 margin-bottom: 10px;
 margin-left: 10px;
 margin-right: 10px;

 scrollbar-base-color: #FFFFFF;
 scrollbar-3dlight-color: #DFDFDF;
 scrollbar-arrow-color: #FFFFFF;
 scrollbar-darkshadow-color: #0E3989;
 scrollbar-face-color: #7F99B2;
 scrollbar-highlight-color: #B3C2D2;
 scrollbar-shadow-color: #000000;
 scrollbar-track-color: #7F99B2;
}
textarea, input, select {
 font-family: Verdana;
 font-size: 10px;
 font-weight: bold;
 color: #0E3989;
 background-color: #FFFFFF;

 border-top-width : 1px;
 border-right-width : 1px;
 border-bottom-width : 1px;
 border-left-width : 1px;

 border-top-color : #000000;
 border-right-color : #000000;
 border-bottom-color : #000000;
 border-left-color : #000000;
}
table {
 font-family: Verdana;
 font-size: 10px;
 text-align: left;
 color: #0E3989;
}
a {
 font-family: Verdana;
 color: #0E3989;
}
a:hover {
 color: #800000;
 text-decoration: none;
}
.black {
 font-family: Verdana;
 font-size: 10px;
 color: #000000;
 font-weight: bold;
}
-->
</style>
</head>

<body bgcolor=\"#FFFFFF\">";


  $query = $database->db_query("SELECT * FROM `fn" . $sql_prefix . "_groups`");
  while($group = @mysql_fetch_array($query)) $export_groups_bit .= "<option value=\"$group[id]\">$group[name]</option>";

  echo "<div align=\"center\"><table width=\"50%\" border=\"0\" bgcolor=\"#7F99B2\" cellpadding=\"4\" cellspacing=\"1\">
 <form action=\"export.php\" method=\"POST\">
 <tr style=\"background-image:url(../acp/images/table_background.gif)\">
   <td colspan=\"2\"><b>Export</b></td>
 </tr>
 <tr>
   <td bgcolor=\"#FFFFFF\" width=\"30%\"><div class=\"black\">Zielgruppe:</div></td>
   <td bgcolor=\"#FFFFFF\" align=\"right\"><select name=\"group\" size=\"1\" style=\"font-family: Helvetica,Arial;\">$export_groups_bit</select></td>
 </tr>
 <tr>
   <td bgcolor=\"#FFFFFF\" width=\"30%\" valign=\"top\"><div class=\"black\">Trennzeichen(kette):</div></td>
   <td bgcolor=\"#FFFFFF\" align=\"left\" valign=\"top\">

   <table cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
   <tr>
     <td valign=\"top\">

     <table cellpadding=\"2\" cellspacing=\"0\">
     <tr>
      <td><input type=\"Radio\" name=\"split\" value=\"break\" checked></td>
      <td valign=\"middle\">Zeilenumbruch</td>
     </tr>
     <tr>
      <td><input type=\"Radio\" name=\"split\" value=\"breakr\"></td>
      <td valign=\"middle\">Zeilenumbruch mit<br>Wagenr�cklauf (\\r\\n)</td>
     </tr>
     <tr>
      <td><input type=\"Radio\" name=\"split\" value=\"other\"></td>
      <td valign=\"middle\">Andere</td>
     </tr>
     </table>

     </td>
     <td valign=\"bottom\" align=\"right\"><input type=\"text\" name=\"split_string\" value=\"\" size=\"25\"></td>
    </tr>
    </table><input type=\"hidden\" name=\"action\" value=\"save\">

   </td>
 </tr>
 <tr>
   <td bgcolor=\"#FFFFFF\" colspan=\"2\" align=\"right\"><input type=\"submit\" name=\"\" value=\"Senden\"></td>
  </tr>
 </form></table></div></body>
</html>";
}

?>



