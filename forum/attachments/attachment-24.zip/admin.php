<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
<title>pgcNews - Administration</title>
<meta name="author" content="programmers-club">
<meta name="generator" content="Stephan Altmann">
<style type="text/css">
<!--
body {
 font-family: Verdana;
 font-size: 10px;
 text-align: left;
 color: #000000;
}
a:link {
 font-family: Verdana;
 font-size: 12px;
 font-weight: bold;
 text-decoration: underline;
 text-align: left;
 color: #000000;
}
a:hover {
 font-family: Verdana;
 font-size: 12px;
 font-weight: bold;
 text-decoration: none;
 text-align: left;
 color: #C00000;
}
a:visited {
 font-family: Verdana;
 font-size: 12px;
 font-weight: bold;
 text-decoration: underline;
 text-align: left;
 color: #000000;
}
TEXTAREA {
 FONT-SIZE: 12px;
 FONT-FAMILY: Verdana;
 COLOR: #000000;
 BACKGROUND-COLOR: #CFCFCF;
}
input {
 FONT-SIZE: 12px;
 FONT-FAMILY: Tahoma,Helvetica;
 COLOR: #000000;
 BACKGROUND-COLOR: #CFCFCF;
}
table {
 font-family: Verdana;
 text-align: left;
 background: #000000;
}
td {
 background: #C0C0C0;
 font-size: 12px;
 text-decoration: bold;
 FONT-FAMILY: Verdana;
}
-->
</style>
</head>
<body >

<?php
include("config_data.php");
include("layout.php");

$sendletter = "admin.php?login=" . $admin_psw;
$editemail = "admin.php?login=" . $admin_psw . "&id=edit";
$datei = fopen("$mailingliste", "r");
$textarea = fgets($datei, 262144);


if($login == $admin_psw)
{
    if($id==edit)
  {
echo
  "<div align=center>
  <table  cellpadding=1 cellspacing=1>
  <tr>
   <td><b>Email-Liste bearbeiten:</b></td>
  </tr>
  <tr>
   <td><textarea name=list_mails cols=80 rows=10 readonly>";
  echo $textarea;
 echo
  "</textarea></td>
  </tr>
  <form action=save.php method=get target=_blank>
  <tr>
   <td><b>Adresse hinzuf�gen:</b> <input type=Text name=save size=25 maxlength= value=>&nbsp; <input type=Submit name=send value=Hinzuf�gen></td>
  </form></tr>
  <tr><form action=del.php method=get target=_blank>
   <td><b>Adresse entfernen:</b> <input type=Text name=searchmail size=25 value=>&nbsp; <input type=Submit name=entf value=Entfernen></td>
  </form></tr>
  <tr>
   <td><b>Hinweis:</b> Um die Liste zu aktualisieren verwenden Sie bitte die Reload-Funktion<br> Ihres Browsers (F5)</td>
  </tr>
  </table><br><br>
    <a href=$sendletter>Newsletter versenden</a>
  </div>";
  }
    else
  {
 echo "
  <form action=mail.php method=post target=_blank>
  <div align=center>
  <table  cellpadding=1 cellspacing=1>
  <tr>
   <td><b>Betreff:</b> <input type=Text name=betreff size=50 maxlength= value=></td>
  </tr>
  <tr>
   <td><textarea name=message cols=80 rows=30></textarea></td>
  </tr>
  <input type=hidden name=pass value=$admin_psw>
  <tr>
   <td><div align=center>
   <input type=Submit name=absenden value=Absenden>&nbsp;
   <input type=Submit name=absenden value=Vorschau></div> </td>
  </tr>
  </form>
  </table><br><br>
   <a href=$editemail>Adressen editieren</a>
  </div>";
  }
}
  else
{
  echo "<div align=center><b>Bitte geben Sie Ihr Passwort f�r den Zugang zum Control Panel ein.</b>
<br><br>
  <table cellspacing=1 cellpadding=3>
  <form action=admin.php method=get>
<tr>
 <td><input type=Text name=login size=35 maxlength=20 value=>
  <input type=Submit name=btnlogin value=Einloggen></td>
</tr>
</table>
  </form></div>";
}

echo "$footer";
?>

</body>
</html>