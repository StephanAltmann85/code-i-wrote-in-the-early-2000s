<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
<title>pgcNews - Newsletter versenden</title>
<meta name="author" content="programmers-club">
<meta name="generator" content="Stephan Altmann">
<style type="text/css">
<!--
body {
 font-family: Verdana;
 font-size: 10px;
 text-align: left;
 color: #000000;
}
a:link {
 font-family: Verdana;
 font-size: 12px;
 font-weight: bold;
 text-decoration: underline;
 text-align: left;
 color: #000000;
}
a:hover {
 font-family: Verdana;
 font-size: 12px;
 font-weight: bold;
 text-decoration: none;
 text-align: left;
 color: #C00000;
}
a:visited {
 font-family: Verdana;
 font-size: 12px;
 font-weight: bold;
 text-decoration: underline;
 text-align: left;
 color: #000000;
}
TEXTAREA {
 FONT-SIZE: 12px;
 FONT-FAMILY: Verdana;
 COLOR: #000000;
 BACKGROUND-COLOR: #CFCFCF;
}
input {
 FONT-SIZE: 12px;
 FONT-FAMILY: Tahoma,Helvetica;
 COLOR: #000000;
 BACKGROUND-COLOR: #CFCFCF;
}
td {
  FONT-FAMILY: Verdana;
  FONT-SIZE: 10px;
}
-->
</style>
</head>
<body >
<?php
include("config_data.php");
include("layout.php");
if($pass == $admin_psw)
{
  if ($absenden == "Absenden")
  {
    $datei = fopen ($mailingliste, "r");
    $size= filesize($mailingliste);
    $daten = fgets ($datei, $size);

    fclose($datei);
    $ziffern = explode(",",$daten);

    reset ($ziffern);
    while (list(, $value) = each ($ziffern)) {
    $send_letter = $value;

    mail("$send_letter","$betreff","$message

$db_remove

$signature","From: $name_mail <$webmaster_mail>","-f$webmaster_mail");}

    echo "Der Newsletter konnte erfolgreich versendet werden.";
  }
  else
  {
  echo ("
<div align=center>
<table width=60%>
<tr >
 <td width=100><b>Betreff:</b></td>
 <td><b><i>$betreff</i></b></td>
</tr>
<tr>
<td></td>
<td></td>
</tr>
<tr valign=top>
 <td width=100><b>Nachricht:</b></td>
 <td><i>$message <br><br>$db_remove<br><br>$signature</i></td>
</tr>
</table>
</div>

   <br><br> ");
  }
 }
else
 {
echo "Sie haben nicht die Berechtigung diese Funktion zu nutzen!";
 }

echo "$footer";
?>
</body>
</html>