1st News 3.5 Professional 
Addon: Zusatzfeld "Name" 0.1

Beschreibung:
F�gt bei der Anmdeldung das zus�tzliche Pflichtfeld "Name" hinzu. Dieser kann dann innerhalb der Newsletter ausgegeben werden.

Funktionen "In Planung" (aktuell nicht realisiert":
-Anpassung der Exportroutine
-Funktion �ber Einstellungen zuschaltbar
-Erweiterung der Suchfunktion
-Anpassung der Best�tigungsmail bei Anmeldung
-Anpassung Archiv-Zugangsanforderung


Installation:
-Folgende Dateien vom Script mit denen aus dem Archiv ersetzen bzw. neu hochladen:
--action.php
--msetup.php
--templates/index_default.htm
--templates/action_error_no_name.htm
--templates/action_admin_activation.htm
--templates/action_done.htm
--templates/action_error_exists.htm
--templates/action_error_incorrect_mail.htm
--templates/save_done.htm
--acp/templates/code_preview_one.htm
--acp/templates/code_preview.htm
--acp/templates/entries.htm
--acp/templates/entries_edit.htm
--acp/templates/entries_bit.htm
--acp/templates/entries_activate.htm
--acp/templates/entries_activate_bit.htm
--acp/templates/entries_add.htm
--acp/templates/entries_add_error_no_name.htm
--acp/templates/newsletter.htm
--acp/templates/templates_add.htm
--acp/templates/templates_edit.htm
--acp/code.js
--acp/index.php
--acp/lib/functions.php

Datei msetup.php ausf�hren und anschliessend vom Server entfernen.

