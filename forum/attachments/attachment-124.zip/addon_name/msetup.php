<?php
include("lib/global.php");
echo "Aktualisiere Datenbankstruktur...";
$database->db_query("ALTER TABLE `fn" . $sql_prefix . "_entries` ADD `name` VARCHAR( 255 ) NOT NULL AFTER `email`");
echo "<br>Vorgang abgeschlossen";
?>
