<?php
function archiv($mail_modus, $groupid, $subject, $textarea, $date, $archiv, $attachments)
{
  global $database, $sql_prefix;

  if($archiv) $query = $database->db_query("INSERT INTO fn" . $sql_prefix . "_archiv (`type`, `groupid`, `subject`, `message`, `date`, `attachments`) VALUES ('$mail_modus', '$groupid', '$subject', '$textarea', '$date', '$attachments')");
  if($attachments)
  {
    $id =  mysql_insert_id();
    $attachments = split(";", $attachments);
    mkdir("archiv/" . $id);
    @chmod("/archiv/" . $id . "/", 0777);

    for ($i=0; $i<count($attachments); $i++)
    {
      @copy("attachments/temp/" . $attachments[$i], "archiv/" . $id . "/" . $attachments[$i]);
    }
  }
}

function send_mail($group, $index, $intervall, $temp_id)
{
  global $database, $sql_prefix;

  $query = $database->db_query("SELECT * FROM fn" . $sql_prefix . "_temp WHERE `id` = '$temp_id'");
  $temp = @mysql_fetch_array($query);

  $query = $database->db_query("SELECT `email`, `name` FROM fn" . $sql_prefix . "_entries WHERE `activated` = 1 AND `group` = $group LIMIT $index, $intervall");

  while($entry = @mysql_fetch_array($query))
  {
    @mail($entry["email"], stripslashes($temp["subject"]), stripslashes(str_replace("[username]", $entry["name"],$temp["message"])), $temp["header"]);
  }
}
?>
