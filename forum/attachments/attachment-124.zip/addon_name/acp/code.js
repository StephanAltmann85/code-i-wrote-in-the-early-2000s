function AddText(text)
{
  if (document.acp_form.textarea.createTextRange && document.acp_form.textarea.caretPos)
  {
    var caretPos = document.acp_form.textarea.caretPos;
    caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
    text + ' ' : text;
  }
  else document.acp_form.textarea.value += text;
  document.acp_form.textarea.focus(caretPos)
}

function CodePreview(target, groups)
{
  i = 1;
  count = 0;

  do
  {
    if(document.acp_form.elements['GroupId_' + i].checked) count++;
    i++;
  }
  while(i <= groups);

  window.open(target + '&count_selected=' + count,'Vorschau','toolbar=no,scrollbars=yes,resizable=no,width=270,height=200');
}

function Combo(groups)
{
  Insert = '';
  i = 1;

  do
  {
    if(document.acp_form.elements['GroupId_' + i].checked)
    {
      Insert = Insert + '<option value="' + document.acp_form.elements['GroupId_' + i].value + '">' + document.acp_form.elements['GroupName_' + i].value + '</option>\r\n';
    }
    i++;
  }
  while(i <= groups);

  return Insert;
}

function Generate(border_color, border_width, border_padding, table_width, path, color_1, color_2, color_3, groups)
{
  Input = '';

  i = 1;
  count = 0;

  do
  {
    if(document.acp_form.elements['GroupId_' + i].checked)
    {
      Input = '<input type="hidden" name="group" value="' + document.acp_form.elements['GroupId_' + i].value + '">';
      count++;
    }
    i++;
  }
  while(i <= groups);

  if(count == 1)
  {
    Insert = '<form action="' + path + 'action.php" method="get" target="_top">\r\n<table width="' + table_width + '" bgcolor="#' + border_color + '" border="0" cellpadding="' + border_padding + '" cellspacing="' + border_width + '">\r\n<tr>\r\n <td bgcolor="#' + color_1 + '"><b>Newsletter</b></td>\r\n</tr>\r\n' + Input + '\r\n<tr>\r\n <td bgcolor="#' + color_2 + '" align="center"><input type="Text" name="name" size="30" maxlength="" value="Name"></td>\r\n</tr>\r\n' + '<tr>\r\n <td bgcolor="#' + color_2 + '" align="center"><input type="Text" name="email" size="30" maxlength="" value="Email"><br>\r\n <input type="Radio" name="action" value="reg" checked> Anmelden <input type="Radio" name="action" value="del"> Abmelden</td>\r\n</tr>\r\n<tr>\r\n <td align="center" bgcolor="#' + color_3 + '"><input type="Submit" name="send" value="Absenden"></td>\r\n</tr>\r\n</table></form>';
  }
  else
  {
    InsertGroups = Combo(groups);
    Insert = '<form action="' + path + 'action.php" method="get" target="_top">\r\n<table width="' + table_width + '" bgcolor="#' + border_color + '" border="0" cellpadding="' + border_padding + '" cellspacing="' + border_width + '">\r\n<tr>\r\n <td bgcolor="#' + color_1 + '"><b>Newsletter</b></td>\r\n</tr>\r\n<tr>\r\n <td bgcolor="#' + color_2 + '" align="center" valign="middle"><b>Gruppe:</b>&nbsp;<select name="group" size="1" style="font-family: Helvetica,Arial;"><option value="nothing">---Gruppe w�hlen---</option>\r\n' + InsertGroups + '</select></td>\r\n</tr>\r\n' + '<tr>\r\n <td bgcolor="#' + color_2 + '" align="center"><input type="Text" name="name" size="30" maxlength="" value="Name"></td>\r\n</tr>\r\n' + '<tr>\r\n <td bgcolor="#' + color_2 + '" align="center"><input type="Text" name="email" size="30" maxlength="" value="Email"><br>\r\n <input type="Radio" name="action" value="reg" checked> Anmelden <input type="Radio" name="action" value="del"> Abmelden</td>\r\n</tr>\r\n<tr>\r\n <td align="center" bgcolor="#' + color_3 + '"><input type="Submit" name="send" value="Absenden"></td>\r\n</tr>\r\n</table></form>';
  }

  document.acp_form.code.value = Insert;
}

function image()
{
  imagetitle = prompt("Titel der Grafik: (otpional)","");
  imagelocation = prompt("Bitte geben Sie den Pfad der einzuf�genden Grafik an:","[attachment]/");

  if ((imagelocation != null) && (imagelocation != ""))
  {
    if ((imagetitle != null) && (imagetitle != ""))
    {
      AddTxt = '<img src="' + imagelocation + '" alt="' + imagetitle + '" border="0">';
      AddText(AddTxt);
    }
    else
    {
      AddTxt = '<img src="' + imagelocation + '" alt="" border="0">';
      AddText(AddTxt);
    }
  }
}

function pre()
{
  AddTxt="<pre></pre>";
  AddText(AddTxt);
}

function email()
{
  mailtitle = prompt("Titel des Verweises: (otpional)","");
  maillocation = prompt("Bitte geben Sie eine Mailadresse an:","mailto:");

  if ((maillocation != null) && (maillocation != ""))
  {
    if ((mailtitle != null) && (mailtitle != ""))
    {
      AddTxt = '<a href="' + maillocation + '">' + mailtitle + '</a>';
      AddText(AddTxt);
    }
    else
    {
      AddTxt = '<a href="' + maillocation + '">' + maillocation + '</a>';
      AddText(AddTxt);
    }
  }
}

function html()
{
  AddTxt='<!doctype html public "-//W3C//DTD HTML 4.0 //EN">\r\n<html>\r\n<head>\r\n<title></title>\r\n<meta name="author" content="">\r\n<meta name="generator" content="1st News">\r\n</head>\r\n<body>\r\n\r\n</body>\r\n</html>';
  AddText(AddTxt);
}

function table()
{
  rows = parseInt(prompt("Anzahl der Zeilen: (nur ganze Zahlen)","1"));
  cols = parseInt(prompt("Anzahl der Spalten: (nur ganze Zahlen)","1"));

  AddTxt = '<table bgcolor="" cellpadding="" cellspacing="" border="0" width="" height="">\r\n';

  if(rows != "NaN" && cols != "NaN")
  {
    for(var row = 0; row < rows; row++)
    {
      AddTxt = AddTxt + '<tr height="">\r\n';

      for(var col = 0; col < cols; col++) AddTxt = AddTxt + ' <td bgcolor="" width=""></td>\r\n';

      AddTxt = AddTxt + '</tr>\r\n';
    }
  }

  AddTxt = AddTxt + '</table>';
  AddText(AddTxt);
}

function bold()
{
  AddTxt="<b></b>";
  AddText(AddTxt);
}

function italicize()
{
  AddTxt="<i></i>";
  AddText(AddTxt);
}

function center()
{
  AddTxt='<div align="center"></div>';
  AddText(AddTxt);
}

function url()
{
  urltitle = prompt("Titel der Zielseite: (otpional)","");
  urllocation = prompt("Bitte geben Sie ein Verweisziel an:","http://");

  if ((urllocation != null) && (urllocation != ""))
  {
    if ((urltitle != null) && (urltitle != ""))
    {
      AddTxt = '<a href="' + urllocation + '">' + urltitle + '</a>';
      AddText(AddTxt);
    }
    else
    {
      AddTxt = '<a href="' + urllocation + '">' + urllocation + '</a>';
      AddText(AddTxt);
    }
  }
}

function underline()
{
  AddTxt="<u></u>";
  AddText(AddTxt);
}

function br()
{
  AddTxt="<br>";
  AddText(AddTxt);
}