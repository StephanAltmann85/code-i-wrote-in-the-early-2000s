<?php
include("../lib/config_data.php");
include("../lib/database_class.php");

$database = new database_class;
$database->db_connect();
$date = time();

$preg = "(^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,4})$)";
?>
<html>
<head>
<title>1st News [Import]</title>
<meta name="author" content="Stephan Altmann">

<style type="text/css">
<!--
body {
 font-family: Verdana;
 font-size: 10px;
 text-align: left;
 color: #0E3989;
 background: #FFFFFF;

 margin-top: 10px;
 margin-bottom: 10px;
 margin-left: 10px;
 margin-right: 10px;

 scrollbar-base-color: #FFFFFF;
 scrollbar-3dlight-color: #DFDFDF;
 scrollbar-arrow-color: #FFFFFF;
 scrollbar-darkshadow-color: #0E3989;
 scrollbar-face-color: #7F99B2;
 scrollbar-highlight-color: #B3C2D2;
 scrollbar-shadow-color: #000000;
 scrollbar-track-color: #7F99B2;
}
textarea, input, select {
 font-family: Verdana;
 font-size: 10px;
 font-weight: bold;
 color: #0E3989;
 background-color: #FFFFFF;

 border-top-width : 1px;
 border-right-width : 1px;
 border-bottom-width : 1px;
 border-left-width : 1px;

 border-top-color : #000000;
 border-right-color : #000000;
 border-bottom-color : #000000;
 border-left-color : #000000;
}
table {
 font-family: Verdana;
 font-size: 10px;
 text-align: left;
 color: #0E3989;
}
a {
 font-family: Verdana;
 color: #0E3989;
}
a:hover {
 color: #800000;
 text-decoration: none;
}
.black {
 font-family: Verdana;
 font-size: 10px;
 color: #000000;
 font-weight: bold;
}
-->
</style>
</head>

<body bgcolor="#FFFFFF">

<?php
switch($_REQUEST["action"])
{
  case "step3": if(is_readable($_REQUEST["file_path"]))
                {
                  if($_REQUEST["split"] == "break") $split_string = "\n";
                  if($_REQUEST["split"] == "breakr") $split_string = "\r\n";
                  if($_REQUEST["split"] == "other") $split_string = $_REQUEST["split_string"];

                  $file = implode("", file($_REQUEST["file_path"], "r"));
                  $entries = split($split_string, $file);
                  $i = 0;

                  while(list(, $value) = each($entries))
                  {
                    if(preg_match("/$preg/", $value))
                    {
                      $query = $database->db_query("SELECT `id` FROM `fn" . $sql_prefix . "_entries` WHERE `email` = '$value'");
                      if(!mysql_num_rows($query)) $database->db_query("INSERT INTO fn" . $sql_prefix . "_entries (`email`, `activated`) VALUES ('$value', '1')");
                      
                      $array_of_mails[$i] = $value;
                      $i++;
                    }
                  }
                  echo "<div align=\"center\"><table width=\"50%\" border=\"0\" bgcolor=\"#7F99B2\" cellpadding=\"4\" cellspacing=\"1\">
 <tr style=\"background-image:url(../acp/images/table_background.gif)\">
   <td><b>Eintr�ge werden gespeichert</b></td>
 </tr>
 <tr>
   <td bgcolor=\"#FFFFFF\" align=\"left\">";
   echo @implode(", ", $array_of_mails);
   echo "</td>
 </tr>
 <tr>
   <td bgcolor=\"#FFFFFF\" align=\"left\"><b>Anzahl:</b> $i</td>
 </tr>
 <tr>
  <td bgcolor=\"#FFFFFF\" align=\"right\"><b>Vorgang abgeschlossen</b></td>
 </tr>
 </table></div>";
                }
                else
                {
                  if(!file_exists($_REQUEST["file_path"])) echo "[Fehler] Der angegebene Pfad ist falsch bzw. die Datei existiert nicht!<br>";
                  echo "[Fehler] Die Datei kann nicht gelesen werden<br><br>";

                  echo "<a href=\"import.php\"><b>Zur�ck</b></a>";
                }
  break;

  case "step2": if($_REQUEST["split"] == "break") $split_string = "\n";
                if($_REQUEST["split"] == "breakr") $split_string = "\r\n";
                if($_REQUEST["split"] == "other") $split_string = $_REQUEST["split_string"];

                if(is_readable($_REQUEST["file_path"]))
                {
                  $file = implode("", file($_REQUEST["file_path"], "r"));
                  $entries = split($split_string, $file);
                  $i = 0;

                  while(list(, $value) = each($entries))
                  {
                    if(preg_match("/$preg/", $value))
                    {
                      $array_of_mails[$i] = $value;
                      $i++;
                    }
                  }
                  echo "<div align=\"center\"><table width=\"50%\" border=\"0\" bgcolor=\"#7F99B2\" cellpadding=\"4\" cellspacing=\"1\">
 <form action=\"import.php\" method=\"POST\">
 <input type=\"hidden\" name=\"file_path\" value=\"$_REQUEST[file_path]\">
 <input type=\"hidden\" name=\"action\" value=\"step3\">
 <input type=\"hidden\" name=\"split_string\" value=\"$_REQUEST[split_string]\">
 <input type=\"hidden\" name=\"split\" value=\"$_REQUEST[split]\">
 <tr style=\"background-image:url(../acp/images/table_background.gif)\">
   <td colspan=\"2\"><b>Eintr�ge</b></td>
 </tr>
 <tr>
   <td bgcolor=\"#FFFFFF\" colspan=\"2\" align=\"left\">";
   echo @implode(", ", $array_of_mails);
   echo "</td>
 </tr>
 <tr>
   <td bgcolor=\"#FFFFFF\" colspan=\"2\" align=\"left\"><b>Anzahl:</b> $i</td>
 </tr>
 <tr>
  <td bgcolor=\"#FFFFFF\" align=\"right\"><input type=\"submit\" name=\"\" value=\"Weiter\"></td></form>
  <td bgcolor=\"#FFFFFF\" align=\"right\"><form action=\"import.php\" method=\"POST\"><input type=\"submit\" name=\"\" value=\"Zur�ck\"></td>
 </tr>
 </form></table></div>";
                }
                else
                {
                  if(!file_exists($_REQUEST["file_path"])) echo "[Fehler] Der angegebene Pfad ist falsch bzw. die Datei existiert nicht!<br>";
                  echo "[Fehler] Die Datei kann nicht gelesen werden<br><br>";

                  echo "<a href=\"import.php\"><b>Zur�ck</b></a>";
                }
  break;

  default: echo "<div align=\"center\"><table width=\"50%\" border=\"0\" bgcolor=\"#7F99B2\" cellpadding=\"4\" cellspacing=\"1\">
 <form action=\"import.php\" method=\"POST\">
 <tr style=\"background-image:url(../acp/images/table_background.gif)\">
   <td colspan=\"2\"><b>Import</b></td>
 </tr>
 <tr>
   <td bgcolor=\"#FFFFFF\" colspan=\"2\"><u><b>Hinweis</b></u><br>
   Geben Sie den relativen Pfad zur Datei mit den Eintr�gen an und bestimmen Sie das Trennzeichen bzw. die Trennzeichenkette zwischen den einzelnen Eintr�gen.</td>
 </tr>
 <tr>
   <td bgcolor=\"#FFFFFF\" width=\"30%\"><div class=\"black\">Adressdatei:</div></td>
   <td bgcolor=\"#FFFFFF\" align=\"right\"><input type=\"text\" name=\"file_path\" value=\"\" size=\"35\"></td>
 </tr>
 <tr>
   <td bgcolor=\"#FFFFFF\" width=\"30%\" valign=\"top\"><div class=\"black\">Trennzeichen(kette):</div></td>
   <td bgcolor=\"#FFFFFF\" align=\"left\" valign=\"top\">

   <table cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
   <tr>
     <td valign=\"top\">

     <table cellpadding=\"2\" cellspacing=\"0\">
     <tr>
      <td><input type=\"Radio\" name=\"split\" value=\"break\" checked></td>
      <td valign=\"middle\">Zeilenumbruch</td>
     </tr>
     <tr>
      <td><input type=\"Radio\" name=\"split\" value=\"breakr\"></td>
      <td valign=\"middle\">Zeilenumbruch mit<br>Wagenr�cklauf (\\r\\n)</td>
     </tr>
     <tr>
      <td><input type=\"Radio\" name=\"split\" value=\"other\"></td>
      <td valign=\"middle\">Andere</td>
     </tr>
     </table>

     </td>
     <td valign=\"bottom\" align=\"right\"><input type=\"text\" name=\"split_string\" value=\"\" size=\"25\"></td>
    </tr>
    </table><input type=\"hidden\" name=\"action\" value=\"step2\">

   </td>
 </tr>
 <tr>
   <td bgcolor=\"#FFFFFF\" colspan=\"2\" align=\"right\"><input type=\"submit\" name=\"\" value=\"Weiter\"></td>
  </tr>
 </form></table></div>";
  break;
}
?>


</body>
</html>
