ALTER TABLE `fn1_options` ADD `notify` INT( 1 ) DEFAULT '0' NOT NULL ;
