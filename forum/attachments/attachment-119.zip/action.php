<?php
include("lib/global.php");

$email = strtolower($_REQUEST["email"]);
$action = $_GET["action"];
$error = $_GET["error"];

$preg = "(^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,4})$)";
$date = time();
$date_print = date("d.m.Y/H:i:s", $date);

eval("\$head = \"".$template->tpl("head.htm")."\";");
eval("\$footer = \"".$template->tpl("footer.htm")."\";");

if(!$email)
{
  $action = "error";
  $error = "no_mail";
}
if(!$_REQUEST["group"])
{
  $action = "error";
  $error = "no_group";
}

$query = $database->db_query("SELECT `admin_activation`, `name` FROM `fn" . $sql_prefix . "_groups` WHERE `id` = '$_REQUEST[group]'");
$group = mysql_fetch_array($query);

$admin_activation = $group["admin_activation"];

switch($action)
{
  case "error": switch($error)
                {
                  case "no_mail": eval("\$message = \"".$template->tpl("action_error_no_mail.htm")."\";");
                  break;

                  case "no_group": eval("\$message = \"".$template->tpl("action_error_no_group.htm")."\";");
                  break;

                  case "not_in_db": eval("\$message = \"".$template->tpl("action_error_not_in_db.htm")."\";");
                  break;

                  case "incorrect_mail": eval("\$message = \"".$template->tpl("action_error_incorrect_mail.htm")."\";");
                  break;

                  case "exists": eval("\$message = \"".$template->tpl("action_error_exists.htm")."\";");
                  break;
                }
  break;

  case "del": $query = $database->db_query("SELECT `id` FROM `fn" . $sql_prefix . "_entries` WHERE `email` = '$email' AND `group` = '$_REQUEST[group]'");
              $entries = mysql_num_rows($query);

              if($entries)
              {
                $query = $database->db_query("DELETE FROM `fn" . $sql_prefix . "_entries` WHERE `email` = '$email' AND `group` = '$_REQUEST[group]'");
                eval("\$message = \"".$template->tpl("action_removed.htm")."\";");
              } else header("Location: action.php?action=error&error=not_in_db&email=$email&group=none");

              $database->db_query("INSERT INTO fn" . $sql_prefix . "_log (`date`, `email`, `group`, `ip`, `action`) VALUES ('$date', '$email', '$_REQUEST[group]', '$_SERVER[REMOTE_ADDR]', 'Abbestellen des Newsletters (action.php)')");
  break;

  default: $database->db_query("INSERT INTO fn" . $sql_prefix . "_log (`date`, `email`, `group`, `ip`, `action`) VALUES ('$date', '$email', '$_REQUEST[group]', '$_SERVER[REMOTE_ADDR]', 'Bestellen des Newsletterabonements (action.php)')");

           $query = $database->db_query("SELECT `id` FROM `fn" . $sql_prefix . "_entries` WHERE `email` = '$email' AND `group` = '$_REQUEST[group]'");
           $entries = @mysql_num_rows($query);
           
           if(!$entries)
           {
             $query_2 = $database->db_query("SELECT `id` FROM `fn" . $sql_prefix . "_groups` WHERE `id` = '$_REQUEST[group]'");
             if(@mysql_num_rows($query_2))
             {
               if(preg_match("/$preg/", $email))
               {
                 $password = password(20);

                 $query = $database->db_query("INSERT INTO fn" . $sql_prefix . "_entries (`email`, `group` ,`activation_code` ,`activated` , `date`) VALUES ('$email', '$_REQUEST[group]', '$password', '0', '$date')");

                 if(!$admin_activation)
                 {
                   $regurl = $options["url"] . "save.php?code=" . $password;
                   $regmail_message = str_replace("{regurl}", $regurl, $options["regmail_message"]);
                   $regmail_message = str_replace("{email}", $email, $regmail_message);

                   $header = $mail->simple_textmail();

                   mail("$email", "$options[regmail_subject]", "$regmail_message", "$header");

                   eval("\$message = \"".$template->tpl("action_done.htm")."\";");
                 } else eval("\$message = \"".$template->tpl("action_admin_activation.htm")."\";");
               } else header("Location: action.php?action=error&error=incorrect_mail&email=$email&group=$_REQUEST[group]");
             } else header("Location: action.php?action=error&error=no_group&email=$email");
           } else header("Location: action.php?action=error&error=exists&email=$email&group=$_REQUEST[group]");
  break;
}

eval("\$template->tpl_output(\"".$template->tpl("action.htm")."\");");

?>
