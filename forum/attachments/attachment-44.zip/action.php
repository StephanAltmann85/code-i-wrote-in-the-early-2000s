<?php
include "config_data.php";
include "lib/template.php";

$email = $_GET["email"];
$del = $_GET["del"];
if($del == "true") $action = del;

echo $action;
echo $email;

$tpl = file_tpl("main.htm");

$preg = "(^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,4})$)";
$datum = date("H:i - l d. F Y");

if($action == "del")
{
  if($email)
  {
    $file = file($mailingliste);
    foreach($file as $line => $send_letter)
    {
      if($email == trim($send_letter)) $found = TRUE;
    }

    if($found == TRUE)
    {
      $search_toremove = $email . "\n";
      $datei = fopen($mailingliste, "r");
      $size = filesize($mailingliste);
      $contents = fread($datei, $size);
      fclose($datei);
      $massreplace = preg_replace("/$search_toremove/", "", $contents);
      $datei = fopen($mailingliste, "w");
      fputs($datei, $massreplace);
      fclose($datei);

      $tpl = tpl_insert("#message", file_tpl("action_removed.htm"));
    } else $tpl = tpl_insert("#message", file_tpl("action_notindb.htm"));

    $fp = fopen("log/ip.log","a");
    $logline = sprintf("%s    %s    %s    %s\n",$datum, $email, $REMOTE_ADDR, "L&ouml;schen einer Mailadresse aus der Datenbank (action.php)");
    fputs($fp, $logline);
    fclose($fp);
  } else $tpl = tpl_insert("#message", file_tpl("action_error.htm"));
}
else
{
  if($email)
  {
    $file = file($mailingliste);
    foreach($file as $line => $send_letter)
    {
      if($email == trim($send_letter)) $found = TRUE;
    }

    if($found != TRUE)
    {
      if (preg_match("/$preg/", $email))
      {
        $timestamp = time();
        $infomail = $firstnews . "save.php?save=" . $email . "&code=" . $timestamp;

        mail("$email","$subject_reg","$regMail
$infomail

Zu registrierende Mailadresse: $email

$signature","From: $name_mail <$webmaster_mail>","-f$webmaster_mail");

        $datei = fopen("protect.txt", "a");
        fputs($datei, $timestamp . ",");
        fclose($datei);

        $tpl = tpl_insert("#message", file_tpl("action_newentry.htm"));
        $tpl = str_replace("\$email", $email, $tpl);
        $tpl = str_replace("\$REMOTE_ADDR", $_SERVER["REMOTE_ADDR"], $tpl);
      } else $tpl = tpl_insert("#message", file_tpl("action_error.htm"));
    } else $tpl = tpl_insert("#message", file_tpl("action_exists.htm"));
  } else $tpl = tpl_insert("#message", file_tpl("action_error.htm"));

  $fp = fopen("log/ip.log","a");
  $logline = sprintf("%s    %s    %s    %s\n",$datum, $email, $REMOTE_ADDR, "Beantragen einer Best&auml;tigungsmail (action.php)");
  fputs($fp, $logline);
  fclose($fp);
}
$tpl = str_replace("\$email", $email, $tpl);

tpl_output($tpl);
?>