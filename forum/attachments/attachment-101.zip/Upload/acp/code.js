function AddText(text)
{
  if (document.acp_form.textarea.createTextRange && document.acp_form.textarea.caretPos)
  {
    var caretPos = document.acp_form.textarea.caretPos;
    caretPos.text = caretPos.text.charAt(caretPos.text.length - 1) == ' ' ?
    text + ' ' : text;
  }
  else document.acp_form.textarea.value += text;
  document.acp_form.textarea.focus(caretPos)
}

function image()
{
  imagetitle = prompt("Titel der Grafik: (otpional)","");
  imagelocation = prompt("Bitte geben Sie den Pfad der einzuf�genden Grafik an:","http://");

  if ((imagelocation != null) && (imagelocation != ""))
  {
    if ((imagetitle != null) && (imagetitle != ""))
    {
      AddTxt = '<img src="' + imagelocation + '" alt="' + imagetitle + '" border="0">';
      AddText(AddTxt);
    }
    else
    {
      AddTxt = '<img src="' + imagelocation + '" alt="" border="0">';
      AddText(AddTxt);
    }
  }
}

function pre()
{
  AddTxt="<pre></pre>";
  AddText(AddTxt);
}

function email()
{
  mailtitle = prompt("Titel des Verweises: (otpional)","");
  maillocation = prompt("Bitte geben Sie eine Mailadresse an:","mailto:");

  if ((maillocation != null) && (maillocation != ""))
  {
    if ((mailtitle != null) && (mailtitle != ""))
    {
      AddTxt = '<a href="' + maillocation + '">' + mailtitle + '</a>';
      AddText(AddTxt);
    }
    else
    {
      AddTxt = '<a href="' + maillocation + '">' + maillocation + '</a>';
      AddText(AddTxt);
    }
  }
}

function html()
{
  AddTxt='<!doctype html public "-//W3C//DTD HTML 4.0 //EN">\r\n<html>\r\n<head>\r\n<title></title>\r\n<meta name="author" content="">\r\n<meta name="generator" content="1st News">\r\n</head>\r\n<body>\r\n\r\n</body>\r\n</html>';
  AddText(AddTxt);
}

function table()
{
  rows = parseInt(prompt("Anzahl der Zeilen: (nur ganze Zahlen)","1"));
  cols = parseInt(prompt("Anzahl der Spalten: (nur ganze Zahlen)","1"));

  AddTxt = '<table bgcolor="" cellpadding="" cellspacing="" border="0" width="" height="">\r\n';

  if(rows != "NaN" && cols != "NaN")
  {
    for(var row = 0; row < rows; row++)
    {
      AddTxt = AddTxt + '<tr height="">\r\n';

      for(var col = 0; col < cols; col++) AddTxt = AddTxt + ' <td bgcolor="" width=""></td>\r\n';

      AddTxt = AddTxt + '</tr>\r\n';
    }
  }

  AddTxt = AddTxt + '</table>';
  AddText(AddTxt);
}

function bold()
{
  AddTxt="<b></b>";
  AddText(AddTxt);
}

function italicize()
{
  AddTxt="<i></i>";
  AddText(AddTxt);
}

function center()
{
  AddTxt='<div align="center"></div>';
  AddText(AddTxt);
}

function url()
{
  urltitle = prompt("Titel der Zielseite: (otpional)","");
  urllocation = prompt("Bitte geben Sie ein Verweisziel an:","http://");

  if ((urllocation != null) && (urllocation != ""))
  {
    if ((urltitle != null) && (urltitle != ""))
    {
      AddTxt = '<a href="' + urllocation + '">' + urltitle + '</a>';
      AddText(AddTxt);
    }
    else
    {
      AddTxt = '<a href="' + urllocation + '">' + urllocation + '</a>';
      AddText(AddTxt);
    }
  }
}

function underline()
{
  AddTxt="<u></u>";
  AddText(AddTxt);
}

function br()
{
  AddTxt="<br>";
  AddText(AddTxt);
}

