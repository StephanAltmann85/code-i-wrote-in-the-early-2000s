<?php
1082311106#stephan@lan1.lan
1082311188#stephan@lan1.lan
1082311192#stephan@lan1.lan
?>