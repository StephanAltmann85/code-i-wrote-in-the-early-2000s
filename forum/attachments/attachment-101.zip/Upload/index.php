<?php
include "lib/config_data.php";
include "lib/template.php";

$template = new template_class;

eval("\$template->tpl_output(\"".$template->tpl("index.htm")."\");");

?>