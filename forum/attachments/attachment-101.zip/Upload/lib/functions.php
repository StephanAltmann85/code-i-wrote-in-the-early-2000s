<?php
function rights($path)
{
  global $rights;

  if(is_writeable($path . "entries/log.php")) $rights["log_write"] = "Ja";
  else $rights["log_write"] = "Nein";

  if(is_writeable($path . "entries/protect.php")) $rights["protect_write"] = "Ja";
  else $rights["protect_write"] = "Nein";

  if(file_exists($path . "entries/mail.php")) $rights["mail_up"] = "Ja";
  else $rights["mail_up"] = "Nein";

  if(file_exists($path . "entries/log.php")) $rights["log_up"] = "Ja";
  else $rights["log_up"] = "Nein";

  if(file_exists($path . "entries/protect.php")) $rights["protect_up"] = "Ja";
  else $rights["protect_up"] = "Nein";
}
function write_mailinglist($to_remove, $file_name, $insert, $path="")
{
  $file = implode("", file($path . $file_name));
  $file_content = str_replace($to_remove, $insert, $file);
  $file = fopen($path . $file_name, "w");
  fputs($file, $file_content);
  fclose($file);
}
function write_file($to_remove, $file_name, $insert, $path="")
{
  $file = implode("", file($path . "entries/" . $file_name));
  $file_content = str_replace($to_remove, $insert, $file);
  $file = fopen($path . "entries/" . $file_name, "w");
  fputs($file, $file_content);
  fclose($file);
}
function add_entry($file, $entry)
{
  $file = fopen($file, "a");
  fputs($file, $entry);
  fclose($file);
}
?>
