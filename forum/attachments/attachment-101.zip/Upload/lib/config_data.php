<?php
$admin_psw = "123456";
$firstnews = "http://www.url.de/newsletter/";
$webmaster_mail = "mail@url.de";
$name_mail = "Homepage - Newsletter";
$db_remove = "Wenn Sie keine weiteren Newsletter erhalten wollen, k�nnen Sie sich unter {firstnews} aus unserer Datenbank austragen.";
$reg_subject = "Newsletter - Registrierung";
$reg_message = "Um Ihre Registrierung f�r diesen Newsletter zu best�tigen, folgen Sie bitte diesem Link: {regurl}

Nach erfolgreicher Registrierung werden wir Sie in regelm��igen Abschnitten �ber Neuigkeiten und wichtige �nderungen informieren.

Zu registrierende Mailadresse: {email}";
$debug = "";
$mailinglist = "../script.txt";
?>
