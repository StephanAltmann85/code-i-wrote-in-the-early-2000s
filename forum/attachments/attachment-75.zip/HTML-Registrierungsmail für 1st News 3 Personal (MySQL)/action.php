<?php
include("lib/global.php");

$email = strtolower($_REQUEST["email"]);
$action = $_GET["action"];
$error = $_GET["error"];

$preg = "(^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,4})$)";
$date = time();
$time = date("H:m");

eval("\$head = \"".$template->tpl("head.htm")."\";");
eval("\$footer = \"".$template->tpl("footer.htm")."\";");

if(!$email)
{
  $action = "error";
  $error = "no_mail";
}

switch($action)
{
  case "error": switch($error)
                {
                  case "no_mail": eval("\$message = \"".$template->tpl("action_error_no_mail.htm")."\";");
                  break;

                  case "not_in_db": eval("\$message = \"".$template->tpl("action_error_not_in_db.htm")."\";");
                  break;

                  case "incorrect_mail": eval("\$message = \"".$template->tpl("action_error_incorrect_mail.htm")."\";");
                  break;

                  case "exists": eval("\$message = \"".$template->tpl("action_error_exists.htm")."\";");
                  break;
                }
  break;

  case "del": $query = $database->db_query("SELECT * FROM `fn" . $sql_prefix . "_entries` WHERE email = '$email'");
              $entries = @mysql_num_rows($query);

              if($entries)
              {
                $query = $database->db_query("DELETE FROM `fn" . $sql_prefix . "_entries` WHERE email = '$email'");
                eval("\$message = \"".$template->tpl("action_removed.htm")."\";");
              } else header("Location: action.php?action=error&error=not_in_db&email=$email");

              $query = $database->db_query("INSERT INTO fn" . $sql_prefix . "_log (`date` ,`email` ,`ip` , `action`) VALUES ('$date', '$email', '$_SERVER[REMOTE_ADDR]', 'L�schen einer Mailadresse aus der Datenbank (action.php)')");
  break;

  default: $query = $database->db_query("SELECT * FROM `fn" . $sql_prefix . "_entries` WHERE email = '$email'");
           $entries = @mysql_num_rows($query);

           if(!$entries)
           {
             if(preg_match("/$preg/", $email))
             {
               $password = password();

               $query = $database->db_query("INSERT INTO fn" . $sql_prefix . "_entries (`email` ,`activation_code` ,`activated` , `date`) VALUES ('$email', '$password', '0', '$date')");

               $regurl = $options["url"] . "save.php?code=" . $password;

               $regmail_message = str_replace("{regurl}", $regurl, $options["regmail_message"]);
               $regmail_message = str_replace("{email}", $email, $regmail_message);

               if($options["reg_html"])
               {
                 $header = $mail->header("html", "", "");

                 mail("$email", "$options[regmail_subject]", $regmail_message, $header);
               }
               else
               {
                 $header = $mail->simple_textmail();

                 mail("$email", "$options[regmail_subject]", $regmail_message, $header);
               }

               eval("\$message = \"".$template->tpl("action_done.htm")."\";");
             } else header("Location: action.php?action=error&error=incorrect_mail&email=$email");
           } else header("Location: action.php?action=error&error=exists&email=$email");

           $query = $database->db_query("INSERT INTO fn" . $sql_prefix . "_log (`date` ,`email` ,`ip` , `action`) VALUES ('$date', '$email', '$_SERVER[REMOTE_ADDR]', 'Beantragen einer Best�tigungsmail (action.php)')");
  break;
}

eval("\$template->tpl_output(\"".$template->tpl("action.htm")."\");");

?>