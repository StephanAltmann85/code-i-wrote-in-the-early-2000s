HTML-Registrierungsmail f�r 1st News 3 Personal (MySQL)


#Installation
1.)F�hren Sie z.B. mit PHPMyAdmin folgende Datenbankabfrage aus:
ALTER TABLE `fn1_options` ADD `reg_html` INT( 1 ) DEFAULT '0' NOT NULL ;

Alternativ k�nnen Sie auch die Datei DB.sql aufrufen.

2.) 
Ersetzten sie folgende Dateien:
-action.php
-acp/index.php
-acp/templates/options_savemail.htm
