HTML-Registrierungsmail f�r 1st News 3 Personal (non MySQL)

#Installation
1.)�ffnen Sie die Datei "lib/config_data.php" und f�gen Sie unterhalb von
$debug = ""; bzw. $debug = "1";

folgendes ein:

$reg_html = "";

2.) 
Ersetzten sie folgende Dateien:
-action.php
-acp/index.php
-acp/templates/options_savemail.htm
