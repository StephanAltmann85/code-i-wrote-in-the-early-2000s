<?php
include "../lib/config_data.php";
include "../lib/template.php";
include "../lib/functions.php";
include "../lib/mail_functions.php";

$template = new template_class;
$mail = new mail_class;

$action = $_REQUEST["action"];
$error = $_GET["error"];
$sid = $_REQUEST["sid"];
$password = $_POST["password"];

session_start();
session_name("sid");
$sid = session_id();

$preg = "(^[_a-zA-Z0-9-]+(\.[_a-zA-Z0-9-]+)*@([a-zA-Z0-9-]+\.)+([a-zA-Z]{2,4})$)";

if($_POST["password"] == $admin_psw && $admin_psw != "")
{
  session_register("password");
  header("Location: index.php?sid=$sid");
}

if($_SESSION["password"] == $admin_psw)
{
  if(!is_writeable("../entries/mail.php") || !is_writeable("../entries/log.php") || !is_writeable("../entries/protect.php"))
  {
    $action = "error";
    $error = "no_rights";
  }

  switch($action)
  {
    case "del_archiv_file": @unlink("archiv/" . $_GET["file"]);
                            header("location: index.php?action=archiv&sid=$sid");
    break;

    case "archiv": $handle = @opendir("archiv/");
                   while ($file_name = @readdir($handle))
                   {
                     if(eregi("^\.{1,2}$",$file_name)) continue;

                     $file_time = date("d.m.Y/H:i:s",filectime("archiv/" . $file_name));
                     $file_tmp_format = split("\.", $file_name);

                     if($file_tmp_format[1] == "htm") eval("\$type = \"".$template->tpl("archiv_html.htm")."\";");
                     else eval("\$type = \"".$template->tpl("archiv_text.htm")."\";");

                     eval("\$archiv_bit .= \"".$template->tpl("archiv_bit.htm")."\";");
                   }

                   eval("\$content = \"".$template->tpl("archiv.htm")."\";");
                   $title = "Archiv";
    break;

    case "preview": if($_POST["mail_modus"] == "html") echo stripslashes($_POST["textarea"]);
                    else
                    {
                      $textarea = stripslashes(nl2br(str_replace(" ", "&nbsp;", htmlspecialchars($_POST["textarea"]))));

                      echo $textarea;
                    }
    break;

    case "send_newsletter": $index = $_GET["index"];
                            $intervall = 1;
                            $index_max = $index + $intervall;

                            $textarea = stripslashes($_POST["textarea"]) . $mail->removal_direction($_POST["mail_modus"]);
                            $subject = stripslashes($_POST["subject"]);

                            if(!$_GET["index"])
                            {
                              if($_POST["archiv"])
                              {
                                $archiv_file = "Newsletter_" . date("d_m_Y-H_i_s");

                                if($_POST["mail_modus"] == "html")
                                {
                                  $file_content = "<b>$subject</b><br><br>$textarea";
                                  $archiv_file_extension = ".htm";
                                }
                                else
                                {
                                  $file_content = "$subject\r\n\r\n$textarea";
                                  $archiv_file_extension = ".txt";
                                }
                                $archiv_data_file = fopen("archiv/" . $archiv_file . $archiv_file_extension,"w");
                                fputs($archiv_data_file, $file_content);
                                fclose($archiv_data_file);
                              }

                              $tmp_header = $mail->header($_POST["mail_modus"], $_POST["attachment"], $_FILES['attachment_file']['name']);

                              if($_POST["attachment"] && $_FILES['attachment_file']['name'])
                              {
                                move_uploaded_file($_FILES['attachment_file']['tmp_name'], $_FILES['attachment_file']['name']);

                                $tmp_message = $mail->body_begin($_POST["mail_modus"]) . $textarea . $mail->body_end($_FILES['attachment_file']['name'], $_FILES['attachment_file']['type']);
                                @unlink($_FILES['attachment_file']['name']);
                              } else $tmp_message = $textarea;


                              $file_tmp_message = fopen("tmp_message.txt","w");
                              fputs($file_tmp_message, $tmp_message);
                              fclose($file_tmp_message);

                              $file_tmp_header = fopen("tmp_header.txt","w");
                              fputs($file_tmp_header, $tmp_header);
                              fclose($file_tmp_header);

                              $file_tmp_subject = fopen("tmp_subject.txt","w");
                              fputs($file_tmp_subject, $subject);
                              fclose($file_tmp_subject);
                            }

                            $message = @implode("", @file("tmp_message.txt"));
                            $header = @implode("", @file("tmp_header.txt"));
                            $subject = @implode("", @file("tmp_subject.txt"));

                            $file = file("../entries/mail.php");
                            while($index <= $index_max && $index <= count($file))
                            {
                              $email = $file[$index];
                              $email = str_replace("\n", "", $email);

                              if($email != "?>" && $email != "<?php" && $email != "")
                              {
                                mail($email,$subject,$message,$header);
                              }

                              if($index == $index_max)
                              {
                                $index++;
                                header("location: index.php?action=send_newsletter&index=$index&sid=$sid");
                              }
                              $index++;
                            }

                            foreach($file as $line => $email)
                            {
                              $email = str_replace("\n", "", $email);

                              if($email != "?>" && $email != "<?php")
                              {
                                eval("\$newsletter_send_bit .= \"".$template->tpl("newsletter_send_bit.htm")."\";");
                              }
                            }

                            eval("\$content = \"".$template->tpl("newsletter_send.htm")."\";");
                            $title = "Newsletter versenden";

                            if($index > count($file))
                            {
                              @unlink("tmp_header.txt");
                              @unlink("tmp_message.txt");
                              @unlink("tmp_subject.txt");
                            }
    break;

    case "newsletter": $upload_max_filesize = get_cfg_var("upload_max_filesize");

                       eval("\$content = \"".$template->tpl("newsletter.htm")."\";");
                       $title = "Newsletter verfassen";
    break;


    case "edit_options_savemail": $file = implode("", file("../lib/config_data.php"));
                                  $file = str_replace("\$reg_subject = \"" . $reg_subject, "\$reg_subject = \"" . stripslashes($_GET["new_reg_subject"]), $file);
                                  $file = str_replace("\$reg_message = \"" . $reg_message, "\$reg_message = \"" . stripslashes($_GET["new_reg_message"]), $file);
                                  $file = str_replace("\$reg_html = \"" . $reg_html, "\$reg_html = \"" . stripslashes($_GET["new_reg_html"]), $file);

                                  if(is_writeable("../lib/config_data.php"))
                                  {
                                    $Datei = fopen("../lib/config_data.php", "w");
                                    fputs($Datei, $file);
                                    fclose($Datei);

                                    header("Location: index.php?action=options_savemail&sid=$sid");
                                  } else header("Location: index.php?action=error&error=update_config&sid=$sid");
    break;

    case "options_savemail": if($reg_html) $checked = "checked";

                             eval("\$content = \"".$template->tpl("options_savemail.htm")."\";");
                             $title = "Einstellungen - Registrierungsmail bearbeiten";
    break;

    case "edit_options_password": if($admin_psw == $_GET["password"])
                                  {
                                    $file = implode("", file("../lib/config_data.php"));
                                    $file = str_replace("\$admin_psw = \"" . $admin_psw, "\$admin_psw = \"" . stripslashes($_GET["new_password"]), $file);

                                    if(is_writeable("../lib/config_data.php"))
                                    {
                                      $Datei = fopen("../lib/config_data.php", "w");
                                      fputs($Datei, $file);
                                      fclose($Datei);

                                      header("Location: logout.php?sid=$sid");
                                    } else header("Location: index.php?action=error&error=update_config&sid=$sid");
                                  } else header("Location: index.php?action=error&error=wrong_password&sid=$sid");
    break;

    case "options_password": eval("\$content = \"".$template->tpl("options_password.htm")."\";");
                             $title = "Einstellungen - Passwort �ndern";
    break;

    case "edit_options_general": $file = implode("", file("../lib/config_data.php"));
                                 $file = str_replace("\$webmaster_mail = \"" . $webmaster_mail, "\$webmaster_mail = \"" . stripslashes($_GET["new_webmaster_mail"]), $file);
                                 $file = str_replace("\$firstnews = \"" . $firstnews, "\$firstnews = \"" . stripslashes($_GET["new_firstnews"]), $file);
                                 $file = str_replace("\$db_remove = \"" . $db_remove, "\$db_remove = \"" . stripslashes($_GET["new_db_remove"]), $file);
                                 $file = str_replace("\$debug = \"" . $debug, "\$debug = \"" . stripslashes($_GET["new_debug"]), $file);
                                 $file = str_replace("\$name_mail = \"" . $name_mail, "\$name_mail = \"" . stripslashes($_GET["new_name_mail"]), $file);

                                 if(is_writeable("../lib/config_data.php"))
                                 {
                                   $Datei = fopen("../lib/config_data.php", "w");
                                   fputs($Datei, $file);
                                   fclose($Datei);
                                 }
                                 header("Location: index.php?action=set_password");
    break;

    case "options_general": if($debug == 1) $checked = "checked";

                            eval("\$content = \"".$template->tpl("options_general.htm")."\";");
                            $title = "Einstellungen - Allgemeine Einstellungen";
    break;

    case "options": eval("\$content = \"".$template->tpl("options.htm")."\";");
                    $title = "Einstellungen";
    break;

    case "save_template": $Datei = fopen("../templates/" . $_POST["template_file"], "w");
                          fputs($Datei, stripslashes($_POST["textarea"]));
                          fclose($Datei);

                          header("Location: index.php?action=templateeditor&template_file=$_POST[template_file]&sid=$sid");
    break;

    case "del_template": if(is_writeable("../templates/" . $_GET["template_file"]))
                         {
                           unlink("../templates/" . $_GET["template_file"]);
                           header("Location: index.php?action=templateeditor&sid=$sid");
                         } else header("Location: index.php?action=error&error=delete_failure&template_file=$_GET[template_file]&sid=$sid");
    break;

    case "templateeditor": if($_GET["template_file"]) $textarea = implode("", file("../templates/" . $_GET["template_file"]));
                           $template_file = $_GET["template_file"];

                           $handle = @opendir("../templates");
                           while ($templates = @readdir($handle))
                           {
                             if(eregi("^\.{1,2}$",$templates))
                             {
                               continue;
                             }
                             eval("\$templateeditor_bit .= \"".$template->tpl("templateeditor_bit.htm")."\";");
                           }
                           @closedir($handle);

                           eval("\$content = \"".$template->tpl("templateeditor.htm")."\";");
                           $title = "Templateeditor - Templates bearbeiten/hinzuf�gen/l�schen";
    break;

    case "del_entries": if(count($_GET["entries"]))
                        {
                          for ($i=0; $i<count($_GET["entries"]); $i++)
                          {
                            write_file($_GET["entries"][$i] . "\n", "mail.php", "", "../");
                          }
                          header("Location: index.php?action=entries&sid=$sid");
                        } else header("Location: index.php?action=error&error=no_mail&sid=$sid");
    break;

    case "add_entry": if($_GET["email"])
                      {
                        if(preg_match("/$preg/", $_GET["email"]))
                        {
                          write_file("\n?>", "mail.php", "\n" . $_GET["email"] . "\n?>", "../");
                          header("Location: index.php?action=entries&sid=$sid");
                        } else header("Location: index.php?action=error&error=incorrect_mail&email=$_GET[email]&sid=$sid");
                      } else header("Location: index.php?action=error&error=no_mail&sid=$sid");
    break;

    case "entries": $file = file("../entries/mail.php");
                    foreach($file as $line => $email)
                    {
                      $email = str_replace("<?php\n", "---Bitte ausw�hlen---", $email);
                      $email = str_replace("\n", "", $email);

                      if($email != "?>") eval("\$entries_bit .= \"".$template->tpl("entries_bit.htm")."\";");
                    }
                    $entries = $line - 1;

                    eval("\$content = \"".$template->tpl("entries.htm")."\";");
                    $title = "Empf�ngerliste verwalten";
    break;

    case "codegen": $firstnews = $firstnews . "action.php";
                    eval("\$content = \"".$template->tpl("codegen.htm")."\";");
                    $title = "Codegenerator - So binden Sie 1st News in Ihr Webprojekt ein.";
    break;

    case "clear_log": $fp = fopen("../entries/log.php","w");
                      fputs($fp, "<?php\n?>");
                      fclose($fp);
                      header("Location: index.php?action=log&sid=$sid");
    break;

    case "log": $size = filesize("../entries/log.php") - 8;
                $sizekb = Round($size / 1024, 3);

                $fp = fopen("../entries/log.php","r");

                while(!feof($fp))
                {
                  $log_line = fgets($fp, 170);
                  $log_line = str_replace("<?php\n", "", $log_line);
                  $log_line = str_replace("?>", "", $log_line);

                  $log = split("#", $log_line);
                  eval("\$log_bit .= \"".$template->tpl("log_bit.htm")."\";");

                  $i++;
                }
                fclose($fp);

                eval("\$content = \"".$template->tpl("log.htm")."\";");
                $title = "Logdatei";
    break;

    case "error": switch($error)
                  {
                    case "wrong_password": eval("\$content = \"".$template->tpl("error_wrong_password.htm")."\";");
                    break;

                    case "update_config": eval("\$content = \"".$template->tpl("error_update_config.htm")."\";");
                    break;

                    case "delete_failure": eval("\$content = \"".$template->tpl("error_delete_failure.htm")."\";");
                    break;

                    case "no_rights": rights("../");
                                      eval("\$content = \"".$template->tpl("error_no_rights.htm")."\";");
                    break;

                    case "no_mail": eval("\$content = \"".$template->tpl("error_no_mail.htm")."\";");
                    break;

                    case "incorrect_mail": eval("\$content = \"".$template->tpl("error_incorrect_mail.htm")."\";");
                    break;
                  }
                  $title = "Es ist ein Fehler aufgetreten!";
    break;

    default: eval("\$content = \"".$template->tpl("welcome.htm")."\";");
             $title = "Willkommen";
    break;
  }
  eval("\$nav = \"".$template->tpl("nav_access.htm")."\";");
}
else
{
  eval("\$nav = \"".$template->tpl("nav_no_access.htm")."\";");
  eval("\$content = \"".$template->tpl("login.htm")."\";");
  $title = "Login - Bitte melden Sie sich an.";
}

if($action != "preview") eval("\$template->tpl_output(\"".$template->tpl("index.htm")."\");");
?>