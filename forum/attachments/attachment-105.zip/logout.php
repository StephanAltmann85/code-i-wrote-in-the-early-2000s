<?php
setcookie ("sesspass");
header("Location: index.php");
?>
