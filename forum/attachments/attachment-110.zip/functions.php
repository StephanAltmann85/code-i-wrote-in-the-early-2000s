<?php
function archiv($mail_modus, $groupid, $subject, $textarea, $date, $archiv, $attachments)
{
  global $database, $sql_prefix;

  if($archiv) $query = $database->db_query("INSERT INTO fn" . $sql_prefix . "_archiv (`type`, `groupid`, `subject`, `message`, `date`, `attachments`) VALUES ('$mail_modus', '$groupid', '$subject', '$textarea', '$date', '$attachments')");
  if($attachments)
  {
    $id =  mysql_insert_id();
    $attachments = split(";", $attachments);
    mkdir("archiv/" . $id);

    for ($i=0; $i<count($attachments); $i++)
    {
      @copy("attachments/temp/" . $attachments[$i], "archiv/" . $id . "/" . $attachments[$i]);
    }
  }
}

function send_mail($group, $index, $intervall)
{
  global $database, $sql_prefix;
  
  $logdatei = "maillog/mlog-" . date("Y-m") . ".txt";
	if (!file_exists($logdatei)) 
	{
		if (!opendir("maillog")) {mkdir("maillog");}
		touch($logdatei);
		if (!file_exists($logdatei)) {die("Logdatei konnte nicht angelegt werden");}
	}

  $log = fopen($logdatei,"a");

  $query = $database->db_query("SELECT * FROM fn" . $sql_prefix . "_temp");
  $temp = @mysql_fetch_array($query);

  $query = $database->db_query("SELECT `email` FROM fn" . $sql_prefix . "_entries WHERE `activated` = 1 AND `group` = $group LIMIT $index, $intervall");

  while($entry = @mysql_fetch_array($query))
  {
    mail($entry["email"], stripslashes($temp["subject"]), stripslashes($temp["message"]), $temp["header"]);
    
    $logeintrag = date("d M Y H:i:s -- ").$entry["email"]." -- ".$temp["subject"]."\r\n";
    fwrite($log, $logeintrag);
  }
  fclose($log);
}
?>
