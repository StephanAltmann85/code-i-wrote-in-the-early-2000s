ActivePorts component, version 0.9.4, freeware.

This component implement part of the NetStat utility functionality by collecting
data about the active ports. Additionally, it checks the active ports against A
list of known Trojan ports and notifies the user about suspected connections.

Data structure definitions and SNMP agent query functions are based partially on
earlier works by G. Schmidt and G. Yourchenko.

Tested with Delphi 5.01.

It's freeware, use at your on risk.

Usage:

Drop A ListView and ActivePorts components on A form, set ActivePorts.ListView
property to the ListView and call ActivePorts.Update method.

Use the IncludePorts property to enable/disable the display of ports that belong
to the LoopBack and Host 0.0.0.0 NetBios and System processes. When both are
disabled, only the active ports that belong to applications will be displayed.
Most of the Trojans activity are in the Host 0.0.0.0 group.

The OpenPorts property is A list [0..PortsCount - 1] of the current open ports,
you can use it if you don't need the ListView display. If you use A timer to
update the list, set the Interval to >= 5 seconds, ports stay open for at least
30 seconds and we don't want to slow other processes.

The Trojans.inf file is the known trojan ports list, updated at 27/10/2000. if
you want to update it, read it's comments.

Demo program included.

Send bug reports to lgm@earthling.net

