<?php
include "lib/config_data.php";
include "lib/template.php";
include "lib/functions.php";

$template = new template_class;

$code = $_GET["code"];
$error = $_GET["error"];
$action = $_GET["action"];
$email = $_GET["email"];

$date = date("H:i - d.m.Y");

eval("\$head = \"".$template->tpl("head.htm")."\";");
eval("\$footer = \"".$template->tpl("footer.htm")."\";");

if(!$code)
{
  $action = "error";
  $error = "no_code";
}
if(!is_writeable("entries/mail.php") || !is_writeable("entries/log.php") || !is_writeable("entries/protect.php"))
{
  $action = "error";
  $error = "no_rights";
}

switch($action)
{
  case "error": switch($error)
                {
                  case "no_rights": rights("");
                                    eval("\$message = \"".$template->tpl("save_error_no_rights.htm")."\";");
                  break;

                  case "no_code": eval("\$message = \"".$template->tpl("save_error_no_code.htm")."\";");
                  break;

                  case "incorrect_code": eval("\$message = \"".$template->tpl("save_error_incorrect_code.htm")."\";");
                  break;

                  case "exists": eval("\$message = \"".$template->tpl("save_error_exists.htm")."\";");
                  break;
                }
  break;

  default: $file = file("entries/protect.php");
           foreach($file as $line => $send_letter)
           {
             $array = split("#", trim($send_letter));
             if($code == $array[0])
             {
               $check_code = TRUE;
               $email = $array[1];
             }
           }

           if($check_code == TRUE)
           {
             $file = file("entries/mail.php");
             foreach($file as $line => $send_letter)
             {
               if($email == trim($send_letter)) $found = TRUE;
             }
             if($found != TRUE)
             {
               write_file($code . "#" . $email . "\n", "protect.php", "");
               write_file("\n?>", "mail.php", "\n" . $email . "\n?>");

               $line = sprintf("\n%s#%s#%s#%s\n?>",$date, $email, $_SERVER["REMOTE_ADDR"], "Speichern der Mailadresse in der Datenbank (save.php)");
               write_file("\n?>", "log.php", $line);

               if($notify)
               {
                 eval("\$notify = \"".$template->tpl("notify.htm")."\";");
                 $header = "From: $name_mail <$webmaster_mail>\n";
                 $header.= "Return-Path: <$webmaster_mail>";

                 mail($webmaster_mail,"Neue Registrierung",$notify,$header);
               }

               eval("\$message = \"".$template->tpl("save_done.htm")."\";");
             }
             else
             {
               header("Location: save.php?action=error&error=exists&email=$email&code=$code");
               write_file($code . "#" . $email . "\n", "protect.php", "");
             }
           } else header("Location: save.php?action=error&error=incorrect_code&code=$code");
  break;
}

eval("\$template->tpl_output(\"".$template->tpl("save.htm")."\");");

?>